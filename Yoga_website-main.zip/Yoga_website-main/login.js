function myfunction(){
    window.location="index2.html";
}